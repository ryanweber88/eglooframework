<?php
namespace eGloo\Utilities\DependencyInjection;

/**
 * 
 * Represents a class "load" definition - this is passed to the service container at runtime to
 * determine which definition is loaded
 * @author Christian Calloway
 *
 */
class Definition { 
	
}