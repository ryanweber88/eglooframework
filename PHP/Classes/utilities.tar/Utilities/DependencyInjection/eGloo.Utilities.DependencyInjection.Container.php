<?php
namespace eGloo\Utilities\DependencyInjection;

/**
 * 
 * Represents a Service container ala Symphony DI; tweaked to understand application
 * context for eGloo framework
 * @author Christian Calloway
 *
 */
class Container { 
	
}